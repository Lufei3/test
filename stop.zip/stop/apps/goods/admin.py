from django.contrib import admin
from goods.models import GoodsType,GoodsSKU,Goods,GoodsImage,IndexGoodsBanner,IndexTypeGoodsBanner,IndexPromotionBanner,Dynamic,GoodsClass,GoodsColor

@admin.register(GoodsType)
class GoodsTypeAdmin(admin.ModelAdmin):
	list_display = ('name','logo','image')

@admin.register(GoodsSKU)
class GoodsSKUAdmin(admin.ModelAdmin):
	list_display = ('type','goods', 'name', 'desc' ,'color','price', 'unite', 'image', 'image2', 'image2', 'stock', 'sales', 'status')

@admin.register(Goods)
class GoodsAdmin(admin.ModelAdmin):
	list_display = ('name', 'detail')

@admin.register(GoodsColor)
class GoodsColorAdmin(admin.ModelAdmin):
	list_display = ('color','de')

@admin.register(GoodsImage)
class GoodsImageAdmin(admin.ModelAdmin):
	list_display = ('sku', 'image')

@admin.register(IndexGoodsBanner)
class IndexGoodsBannerAdmin(admin.ModelAdmin):
	list_display = ('sku', 'image', 'index')

@admin.register(IndexTypeGoodsBanner)
class IndexTypeGoodsBannerAdmin(admin.ModelAdmin):
	list_display = ('type', 'sku', 'display_type', 'index')

@admin.register(IndexPromotionBanner)
class IndexPromotionBannerAdmin(admin.ModelAdmin):
	list_display = ('name', 'url', 'image', 'index')

@admin.register(Dynamic)
class DynamicAdmin(admin.ModelAdmin):
	list_display = ('name','centent', 'image','detail', 'index')

@admin.register(GoodsClass)
class GoodsClassAdmin(admin.ModelAdmin):
	list_display = ('type','parameter_1','parameter_2','parameter_3','parameter_4')
