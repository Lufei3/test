from django.shortcuts import render
from django.core.paginator import Paginator
from django.core.paginator import Paginator
from goods.models import GoodsType,IndexGoodsBanner,IndexPromotionBanner,IndexTypeGoodsBanner,GoodsSKU,Dynamic,GoodsClass
from cart.models import Addcart

# Create your views here.
def index(request):

	types = GoodsType.objects.all()

	dynamics =  Dynamic.objects.all()[0:4]

	products = GoodsSKU.objects.all()

	product_class = GoodsClass.objects.all()

	goods_banners = IndexGoodsBanner.objects.all().order_by('index')

	promotion_banners = IndexPromotionBanner.objects.all().order_by('index')

	type_goods_banners = IndexTypeGoodsBanner.objects.all()


	# user = request.user.username
	# products = Addcart.objects.filter(user=user)
	# num = len(products)
	# cart_count = 0
	user = request.user.username
	num = Addcart.objects.filter(user=user)
	num = len(num)
	for type in types:
		product = IndexTypeGoodsBanner.objects.filter(type=type)
		type.product_type = product

	context = {	'types':types,
				'goods_banners':goods_banners,
				'promotion_banners':promotion_banners,
				'type_goods_banners':type_goods_banners,
				# 'cart_count':cart_count,
				'products':products ,
				'types':types,
				'dynamics':dynamics,
				'product_class':product_class,
				'num':num,


	}
	return render(request, 'index.html',context)



def products(request,type_id,page):
	if type_id == '0':
		products = GoodsSKU.objects.all()
	else:
		type = GoodsType.objects.get(id=type_id)
		type_2 = GoodsClass.objects.filter(type=type)
		products = []
		for i in GoodsSKU.objects.all():
			for j in type_2:
				if i.type_id == j.id:
					products.append(i)



	# for i in type_2:
	# 	products = GoodsSKU.objects.filter(type_id=i.id)

	page = 1
	num = 12
	page_now = int(page)
	page = int(page)
	# products = GoodsSKU.objects.all()
	product_page = Paginator(products,num)
	pages_products = product_page.page(page)
	page = product_page.num_pages

	pages = []
	while page > 0:
		pages.append(page)
		page = page-1
	pages.reverse()
	
	number = 1
	types = GoodsType.objects.all()
	context = { 'types':types, 
				'products':products,
				'page_now':page_now,
				'number':number,
				'pages_products':pages_products,
				'pages':pages,
				'type_id':int(type_id),
				}
		
	return render(request, 'product.html', context)




def product_details(request, details):
	types = GoodsType.objects.all()
	product_type = GoodsSKU.objects.get(id=details)
	product_class = GoodsClass.objects.all()
	pro = product_type.type
	for i in product_class:
		if i.name == product_type.type:
			pro = i
	context = {'product':product_type,'p':pro,'test':product_class,'types':types}
	return render(request, 'product_details.html', context)
	

def contact(request):
	types = GoodsType.objects.all()
	context = {'types':types}
	return render(request, 'contact.html',context)


def test(request):
	return render(request, 'test.html')

num = 8
def dynamic(request, page_click=1):
	dynamics = Dynamic.objects.all()
	dynamics_page = Paginator(dynamics, num)
	dynamics_num = dynamics_page.num_pages
	pages=[]
	while dynamics_num > 0:
		pages.append(dynamics_num)
		dynamics_num = dynamics_num -1
	pages.reverse()
		
	page_click = int(page_click)
	dynamices_clicks = dynamics_page.page(page_click)
	types = GoodsType.objects.all()
	context = {'dynamices_clicks': dynamices_clicks,  'pages':pages, 'pre_page':page_click,'dynamics':dynamics,'types':types}
	return render(request, 'dynamic.html',context)

def article(request, num):
	dynamics = Dynamic.objects.all()
	dynamic = Dynamic.objects.get(id = num )
	num_id = int(dynamic.id)
	context = { 'num': num, 'dynamic':dynamic, 'dynamics':dynamics, 'num_id': num_id, }
	return render(request, 'article.html', context)



def other(request):
	return render(request, 'other.html')