from django.conf.urls import url
from goods import views
urlpatterns = [
 	url(r'^$', views.index, name='index'),
 	url(r'^other$', views.other, name='other'),
 	url(r'products/(?P<type_id>\w+)/(?P<page>\d+)$', views.products, name='products'),
 	url(r'test$', views.test, name='test'),
 	url(r'dynamic$', views.dynamic, name='dynamic'),
 	url(r'contact$', views.contact, name='contact'),
 	url(r'article/(?P<num>\d+)$', views.article, name='article'),
 	url(r'dynamic/(?P<page_click>\d+)$', views.dynamic, name='dynamic'),
 	url(r'product/(?P<details>\d+)$', views.product_details, name='product_details'),
]
