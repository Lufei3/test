from django.contrib import admin
from order.models import OrderInfo,OrderGoods
# Register your models here.
@admin.register(OrderInfo)
class OrderInfoAdmin(admin.ModelAdmin):
	list_display = ('order_id', 'user', 'addr', 'pay_method', 'total_count', 'total_price', 'transit_price', 'order_status', 'trade_no')

@admin.register(OrderGoods)
class OrderGoodsAdmin(admin.ModelAdmin):
	list_display = ('order', 'sku', 'count', 'price', 'comment')
