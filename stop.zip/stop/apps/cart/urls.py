from django.conf.urls import url
from cart import views
urlpatterns = [
 	url(r'^add$',views.cartadd, name='cartadd'),
 	url(r'^del$',views.cartdel, name='cartdel'),
]
