from django.contrib import admin
from cart.models import Addcart

@admin.register(Addcart)
class AddcartAdmin(admin.ModelAdmin):
	list_display = ('user','product','num','color')
