from django.db import models
from db.base_model import BaseModel
# Create your models here.
class Addcart(BaseModel):
    '''地址模型类'''
    user = models.CharField(max_length=20, verbose_name='用户')
    product = models.CharField(max_length=20, verbose_name='产品ID')
    num = models.CharField(max_length=256, verbose_name='数量')
    color= models.CharField(max_length=20, verbose_name='颜色', null=True, blank=True)

    class Meta:
	    db_table = 'df_product_cart'
	    verbose_name = '购物车'
	    verbose_name_plural = verbose_name

