from django.shortcuts import render
from django.http import JsonResponse

from goods.models import GoodsSKU
from cart.models import Addcart
from django_redis import get_redis_connection
from django.contrib.auth import authenticate, login, logout

# Create your views here.
def cartadd(request):
	if request.method == "POST":
		user = request.user
		if user.is_authenticated == False:
			return JsonResponse({'res':0, 'errmsg':'请先登录'})
		sku_id = request.POST.get('sku_id')
		count = request.POST.get('count')
		count = int(count)

		# 校验
		if not all([sku_id, count]):
			return JsonResponse({'res':1, 'errmsg':'请选择完整'})

		try:
			count = int(count)
		except Exception as e:
			return JsonResponse({'res':2, 'errmsg':'商品数目出错'})

		try:
			sku = GoodsSKU.objects.get(id=sku_id)
		except GoodsSKU.DoesNotExist:
			return JsonResponse({'res':3, 'errmsg': '商品不存在'})
	
		user = request.user.username
		try:
			product = Addcart.objects.get(user=user, product = sku_id)
			num = int(product.num) + count;
			product.num = num
			product.save()
		except Addcart.DoesNotExist:
			Addcart.objects.create(user=user, product = sku_id, num = count, color="空")
			return JsonResponse({'res':5, 'message': "添加成功1"})
		return JsonResponse({'res':5, 'message': "添加成功2"})

def cartdel(request):
	user = request.user.username
	product_id = request.POST.get('product_id')
	Addcart.objects.filter(product=product_id, user=user).delete()
	return JsonResponse({'message':"删除成功!"})

	

	