from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from user.models import User,Address

# Register your models here.

admin.site.register(User, UserAdmin)

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
	list_display = ('user', 'receiver', 'addr', 'zip_code', 'phone', 'is_default')