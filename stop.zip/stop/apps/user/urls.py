from django.conf.urls import url
from user import views
from django.contrib.auth.decorators import login_required

urlpatterns = [
	url(r'^login$', views.mylogin, name='login'),
	url(r'^logout$', views.mylogout, name='logout'),
	url(r'^register$', views.register, name='register'),
	url(r'^active/(?P<token>.*)$',views.active, name='active'),
	url(r'^user_centent$',login_required(views.user_centent), name='user_centent'),
	url(r'^user_address$',login_required(views.user_address), name='user_address'),
	url(r'^user_order/(?P<page>.*)$',login_required(views.user_order), name='user_order'),
	url(r'^user_collection$', views.user_collection, name='user_collection'),
]
