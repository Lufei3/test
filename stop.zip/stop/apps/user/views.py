from django.shortcuts import render,redirect
from django.urls import reverse
from user.models import User,Address
from django.core.mail import send_mail
from user import models
from cart.models import Addcart
from goods.models import GoodsSKU,GoodsType
from django.conf import settings
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
import re
from django.core.mail import send_mail
from itsdangerous import SignatureExpired
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from django.core.paginator import Paginator


# Create your views here.

def register(request):
	if request.method == 'GET':
		return render(request, 'register.html')
	else:
		username = request.POST.get('username')
	password = request.POST.get('pwd')
	email = request.POST.get('email')

	if not all([username, password, email]):
		return render(request, 'register.html', {'errmsg_all':'数据不完整'})
	
	if not re.match(r'^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$' ,email):
		return render(request, 'register.html', {'errmsg_email':'邮箱格式不正确'})
	try:
		user = User.objects.get(username=username)
	except User.DoesNotExist:
		user = None
	if user:
		return render(request, 'register.html', {'errmsg_name':'用户已经存在'})

	user = User.objects.create_user(username, email, password, is_active= 0)
	user.save

	serializer = Serializer(settings.SECRET_KEY, 3600)
	info = {'confirm':user.id}
	token = serializer.dumps(info)
	token = token.decode()

	subject = ' 毅思电脑 '
	message = '正文'
	sender = settings.EMAIL_FROM
	receiver = [email]
	html_message = '<h1>%s, 欢迎您称为毅思电脑的注册会员</h1> 请点击下面的链接激活了您的账户<br/><a href="http://127.0.0.1:8000/user/active/%s">http://127.0.0.1:8000/user/active/%s</a>' %(username, token, token)

	send_mail(subject, message,sender,receiver, html_message=html_message)

	return redirect(reverse('goods:index'))

def active(request, token):
	serializer = Serializer(settings.SECRET_KEY, 3600)
	try:
		info = serializer.loads(token)
		user_id = info['confirm']
		user = User.objects.get(id=user_id)
		user.is_active = 1
		user.save()

		return redirect(reverse('user:login'))
	except SignatureExpired as e:
		return HttpResponse('激活链接过期')



def mylogin(request):
	if request.method == 'GET':
		if 'username' in request.COOKIES:
			username = request.COOKIES.get('username')
			checked = 'checked'
		else:
			username = ''
			checked = ''
		return render(request, 'login.html',{'username':username, 'checked':checked})
	else:
		username = request.POST.get('username')
		password = request.POST.get('pwd')
	
		if not all([username, password]):
			return render(request, 'login.html', {'errmsg':'输入不完整'})

		user = authenticate(username=username, password=password)
		if user is not None:
			if user.is_active:
				login(request, user)

				next_url = request.GET.get('next', reverse('goods:index'))
				response = redirect(next_url)

				remember = request.POST.get('remember')

				if remember == 'on':
					response.set_cookie('username', username)
				else:
					response.delete_cookie('username')

				return response
				
			else:
				return render(request, 'login.html', {'errmsg':'账户未激活'})
		else:
			return render(request, 'login.html', {'errmsg':'用户名或密码错误'})

def mylogout(request):
	logout(request)
	return redirect(reverse('goods:index'))

def user_centent(request):
	user = request.user
	try:
		address = Address.objects.get(user=user)
	except Address.DoesNotExist:
		address = None;

	return render(request, 'user_centent.html',{'page':'centent', 'address':address})

def user_address(request):
	if request.method == 'GET':
		user = request.user
		try:
			address = Address.objects.get(user=user, is_default=True)
		except Address.DoesNotExist:
			address = None
		return render(request, 'user_address.html',{'page':'address','address':address})
	else:
		receiver = request.POST.get('info_name')
		phone = request.POST.get('info_phone')
		zip_code = request.POST.get('info_number') 
		addr = request.POST.get('info_address')

		if not all([receiver, addr, phone]):
			return render(request, 'user_address.html', {'errmsg':'数据不完整'})

		if not re.match(r'^1[3|4|5|6|7|8][0-9]{9}$', phone):
			return render(request, 'user_address.html', {'errmsg':'号码格式错误'})

		user = request.user
		try:
			address = Address.objects.get(user=user, is_default=True)
		except Address.DoesNotExist:
			address = None

		if address:
			is_default = False
		else:
			is_default = True
		
		Address.objects.create( user=user,receiver = receiver,addr = addr,zip_code = zip_code,phone = phone,is_default = is_default)


		return redirect(reverse('user:user_address'))



def user_order(request,page):	
	
	page = int(page)
	user = request.user.username
	carts = Addcart.objects.filter(user=user)

	products = []
	for cart in carts:
	 	product = GoodsSKU.objects.get(id=cart.product)
	 	product.num = cart.num
	 	products.append(product)

	num = 4

	product_centent = Paginator(products, num)
	page_num = product_centent.num_pages 
	products = product_centent.page(page)

	pro = product_centent.page_range

	context = {'cart_products':products, 'pro':pro,'page':page}
	return render(request, 'user_order.html', context )

def user_collection(request):
	return render(request, 'user_collection.html',{'page':'collection'})



