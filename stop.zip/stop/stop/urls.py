from django.conf.urls import include,url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^tinymce', include('tinymce.urls')),
    url(r'^user/',include(('user.urls', 'user'), namespace='user')),
    url(r'^cart/',include(('cart.urls', 'cart'), namespace='cart')),
    url(r'^search',include('haystack.urls')),
    url(r'^order/',include(('order.urls', 'order'), namespace='order')),
    url(r'^',include(('goods.urls', 'goods'), namespace='goods')),
    url(r'ckeditor/', include('ckeditor_uploader.urls')),
    
]

urlpatterns +=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
