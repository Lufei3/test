$(document).ready(function(){
	$("input[name='test']").click(function(){
		$(this).(".li_2").slideToggle("show");
	});
});