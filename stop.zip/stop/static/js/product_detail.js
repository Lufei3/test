$(document).ready(function(){
	var home = $(".home");
	var ul = home.find("ul");
	var oneWidth = home.find("ul li").eq(0).width();
	var number = $(".title").find("span");
	var time = null;
	var sw = 0;

	number.on("click",function(){
		$(this).addClass("active").siblings("span").removeClass("active");
		sw=$(this).index();
		ul.animate({
            "right":oneWidth*sw,   
        });
	});
	$(".next").stop(true, true).click(function(){
		sw++;
		if(sw==number.length){sw=0};
		number.eq(sw).trigger("click");
	});
  	$(".prev").stop(true,true).click(function (){
   		sw--;
	    if(sw==number.length){sw=0};
	    number.eq(sw).trigger("click");
    });

    

    
 	var amout = $("#amout").text();
    var num = $("#number").val();
    var price = $('.product_price').children('em').text();

    function updateMondy(){
    	num = parseInt(num);
    	price = parseFloat(price);
    	sum = num*price;
    	$("#amout").text(sum.toFixed(2)+"元");
    }
    updateMondy();
	$("#number_add").click(function(){
		num++;
		$("#number").val(num);
		updateMondy();
	});

	$("#number_reduce").click(function(){
		if(num>1){
		num--;
		$("#number").val(num);
		}else{
			$("#input").val(1);
		}
		updateMondy();
	});

	$("#number").keyup(function(){
		count = $(this).val();
		if(isNaN(count) || count.trim().length==0 || parseInt(count) <=0){
			count = 1
		}
		$(this).val(parseInt(count));
		updateMondy();
	});




	$("#add_cart").click(function(){
		sku_id = $(this).attr('sku_id')
		csrf = $('input[ name="csrfmiddlewaretoken"]').val()
		params = { 'sku_id': sku_id, 'count':num, 'csrfmiddlewaretoken':csrf }
		$.post('/cart/add', params, function(data){
			if (data.res ==5 ){
				alert(data.message)
			}else{
			alert(data.errmsg)
		}
		})
	})

	
 

});


